exports.vod = {
  accessKeyId: 'LTAI4FzgRRRN2MjwBzc3xQtp',
  accessKeySecret: 'xAllGuORtBDVcrTQpTOWu4HfjYgN1p'
}
