<template>
  <div class="sc-AxmLO gmtmqV">
    <div class="sc-fzokOt hLgJkJ">
      <h2>Recommended</h2>
      <div class="sc-fzoLsD fYZyZu">
        <a href="/watch/3ac30e23-45a6-4eca-9430-3654142a772c"
          ><div class="sc-fzozJi dteCCc">
            <img
              class="thumb"
              src="https://res.cloudinary.com/tylerdurden/video/upload/v1610602989/youutbeclone/jcxdkn7kwykw2oyk95up.jpg"
              alt="thumbnail"
            />
            <div class="video-info-container">
              <div class="channel-avatar">
                <img
                  src="https://res.cloudinary.com/tylerdurden/image/upload/v1610602675/youutbeclone/cyytoyb0dtzouizokimz.jpg"
                  alt="channel avatar"
                  class="sc-AxhCb eSwYtm"
                  style="margin-right: 0.8rem"
                />
              </div>
              <div class="video-info">
                <h4>Twitter clone</h4>
                <span class="secondary">manikandanraji</span>
                <p class="secondary">
                  <span>6 views</span> <span>•</span> <span>22 days ago</span>
                </p>
              </div>
            </div>
          </div></a
        ><a href="/watch/05f411f6-9c9d-4e97-8d65-47847cd99e87"
          ><div class="sc-fzozJi dteCCc">
            <img
              class="thumb"
              src="https://res.cloudinary.com/tylerdurden/video/upload/v1610602948/youutbeclone/oyd7npz8vjcspr2musrl.jpg"
              alt="thumbnail"
            />
            <div class="video-info-container">
              <div class="channel-avatar">
                <img
                  src="https://res.cloudinary.com/tylerdurden/image/upload/v1610602675/youutbeclone/cyytoyb0dtzouizokimz.jpg"
                  alt="channel avatar"
                  class="sc-AxhCb eSwYtm"
                  style="margin-right: 0.8rem"
                />
              </div>
              <div class="video-info">
                <h4>Youtubeception</h4>
                <span class="secondary">manikandanraji</span>
                <p class="secondary">
                  <span>1 views</span> <span>•</span> <span>22 days ago</span>
                </p>
              </div>
            </div>
          </div></a
        ><a href="/watch/b4bafa92-b60d-40a8-ad50-ecd47406edd5"
          ><div class="sc-fzozJi dteCCc">
            <img
              class="thumb"
              src="https://res.cloudinary.com/tylerdurden/video/upload/v1610602919/youutbeclone/ahgq3a0glak3sjahvx6n.jpg"
              alt="thumbnail"
            />
            <div class="video-info-container">
              <div class="channel-avatar">
                <img
                  src="https://res.cloudinary.com/tylerdurden/image/upload/v1610602675/youutbeclone/cyytoyb0dtzouizokimz.jpg"
                  alt="channel avatar"
                  class="sc-AxhCb eSwYtm"
                  style="margin-right: 0.8rem"
                />
              </div>
              <div class="video-info">
                <h4>Instaclone</h4>
                <span class="secondary">manikandanraji</span>
                <p class="secondary">
                  <span>1 views</span> <span>•</span> <span>22 days ago</span>
                </p>
              </div>
            </div>
          </div></a
        ><a href="/watch/e73d8a64-0819-4cb9-be16-fe4599814a61"
          ><div class="sc-fzozJi dteCCc">
            <img
              class="thumb"
              src="https://res.cloudinary.com/tylerdurden/video/upload/v1610602785/youutbeclone/bnzylyplrysa8kmymvye.jpg"
              alt="thumbnail"
            />
            <div class="video-info-container">
              <div class="channel-avatar">
                <img
                  src="https://res.cloudinary.com/tylerdurden/image/upload/v1610602675/youutbeclone/cyytoyb0dtzouizokimz.jpg"
                  alt="channel avatar"
                  class="sc-AxhCb eSwYtm"
                  style="margin-right: 0.8rem"
                />
              </div>
              <div class="video-info">
                <h4>Podcasts Webapp</h4>
                <span class="secondary">manikandanraji</span>
                <p class="secondary">
                  <span>0 views</span> <span>•</span> <span>22 days ago</span>
                </p>
              </div>
            </div>
          </div></a
        ><a href="/watch/f9dae74d-8aad-499b-bd62-ef28e44a74fd"
          ><div class="sc-fzozJi dteCCc">
            <img
              class="thumb"
              src="https://res.cloudinary.com/tylerdurden/video/upload/v1610602720/youutbeclone/xrtkzszgbffj6hbtwdju.jpg"
              alt="thumbnail"
            />
            <div class="video-info-container">
              <div class="channel-avatar">
                <img
                  src="https://res.cloudinary.com/tylerdurden/image/upload/v1610602675/youutbeclone/cyytoyb0dtzouizokimz.jpg"
                  alt="channel avatar"
                  class="sc-AxhCb eSwYtm"
                  style="margin-right: 0.8rem"
                />
              </div>
              <div class="video-info">
                <h4>Leetcode styled SPA</h4>
                <span class="secondary">manikandanraji</span>
                <p class="secondary">
                  <span>0 views</span> <span>•</span> <span>22 days ago</span>
                </p>
              </div>
            </div>
          </div></a>
      </div>
    </div>
  </div>
</template>
